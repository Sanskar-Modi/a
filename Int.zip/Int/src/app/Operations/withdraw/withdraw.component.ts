import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router'
import {BankService} from '../../Service/bank.service'
@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  withdrawForm: FormGroup
  submitted:boolean = false

  constructor( private formBuilder: FormBuilder,private router: Router,private bankService: BankService ) {
      this.formBuilder = formBuilder
   }

   ngOnInit() {

    this.withdrawForm = this.formBuilder.group({
      amount: ['',[
        Validators.required,
        Validators.maxLength(10),
        Validators.pattern('[0-9]+')  // validates input is digit
      ]]
  });
  }


  onSubmit(){
    this.submitted = true;

    // stop here if form is invalid
    if (this.withdrawForm.invalid) {
        return;
    }

    var amount = this.withdrawForm.get("amount").value
    var isWithdraw = this.bankService.withdrawAmount(amount);
    if(isWithdraw != -1){
      alert('Withdraw successful. Current Balance :  '+this.bankService.showBalance());
      this.router.navigate(['/useractions']);
    }
    else{
      alert('Withdraw Failed , Try again');
      this.router.navigate(['/Operations/withdraw']);
    }
    
    
  }

}
