import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BankService } from '../../Service/bank.service'

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {


  registerForm: FormGroup;
  loading = false;
  submitted = false;

   
    constructor(  private formBuilder: FormBuilder,private router: Router,private bankService: BankService ) { 
      this.formBuilder = formBuilder;
      this.router = router;
  }

  ngOnInit() {

    this.registerForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      number: ['',[
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
        Validators.pattern('[0-9]+')  // validates input is digit
      ]],
      address: ['', Validators.required],
      balance: ['',[
        Validators.required,
        Validators.pattern('[0-9]+')  // validates input is digit
      ]],
  });
  }

  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
        return;
    }
    var userName = this.registerForm.get('username').value;
    var password = this.registerForm.get('password').value;
    var phoneNumber = this.registerForm.get('number').value;
    var address = this.registerForm.get('address').value;
    var balance = this.registerForm.get('balance').value;
    var accountObj = this.bankService.createAccount(userName,password,phoneNumber,address,balance);
    var accountNumber;
    accountObj.subscribe((data)=> {
      accountNumber = data['accountNo']
    })
    // if( accountNumber != -1){

    //   alert('Account Created with Account Number:  '+accountNumber);
    //   this.router.navigate(['login']);

    // }
    // else{
    //   alert('Cannot Create Account');
    //   this.router.navigate(['/create']);
    // }
}


}
