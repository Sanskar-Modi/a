import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BankService } from '../../Service/bank.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

 
  loginForm: FormGroup;
  loading = false;
  submitted = false;



  constructor(  private formBuilder: FormBuilder,private router: Router,private bankService: BankService) { 
    this.formBuilder = formBuilder;
    this.router = router;
}

  ngOnInit() {

    this.loginForm = this.formBuilder.group({
      accountid: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]]
    
  });
  }

  onSubmit(){
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
        return;
    }

    var accountid = this.loginForm.get("accountid").value;
    var password = this.loginForm.get("password").value;

    if(this.bankService.loginUser(accountid,password)){
      alert('Login successful');
      this.router.navigate(['/useractions']);
    }
    else{
      alert('Login Failed');
      //this.router.navigate(['/signin']);
    }
    
   
  }
}
