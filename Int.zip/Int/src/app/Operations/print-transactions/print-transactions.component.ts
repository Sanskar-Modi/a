import { Component, OnInit } from '@angular/core';
import { BankService } from '../../Service/bank.service';
import { Transactions } from '../../Models/Transactions';
@Component({
  selector: 'app-print-transactions',
  templateUrl: './print-transactions.component.html',
  styleUrls: ['./print-transactions.component.css']
})
export class PrintTransactionsComponent implements OnInit {

  transactions:Transactions[] = [];

  constructor(
    private bankService:BankService
  ) { }

  ngOnInit() {

    this.transactions = this.bankService.printTransactions();
    console.log(this.transactions)

  }

}
