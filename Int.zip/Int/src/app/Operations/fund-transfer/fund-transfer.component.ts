import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router'
import { BankService } from '../../Service/bank.service'
import { error } from 'util';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  fundtransferForm : FormGroup
  submitted:boolean = false;

  constructor( private formBuilder:FormBuilder, private router:Router, private bankService: BankService ) { 
      this.formBuilder = formBuilder;;
  }


  ngOnInit() {

    this.fundtransferForm = this.formBuilder.group({
      accountid: ['', Validators.required],
      amount: ['',[
        Validators.required,
        Validators.maxLength(10),
        Validators.pattern('[0-9]+')  // validates input is digit
      ]]
  });
  }

  get f() { return this.fundtransferForm.controls; }

  onSubmit(){
    this.submitted = true;

    // stop here if form is invalid
    if (this.fundtransferForm.invalid) {
        return;
    }

    var amount = this.fundtransferForm.get("amount").value;
    var accountid = this.fundtransferForm.get("accountid").value;
    
    if(this.bankService.fundTransfer(accountid,amount)){
      alert('Transfer successful');
      this.router.navigate(['/useractions']);
    }
    else{
      alert('Transfer Failed , Try again');
      this.router.navigate(['/useractions/fundtransfer']);
    }
    
 
  }
  

}
