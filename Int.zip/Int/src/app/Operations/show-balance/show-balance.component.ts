import { Component, OnInit } from '@angular/core';
import { BankService } from '../../Service/bank.service';
@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {

  constructor(private bankService:BankService ) {

   }

  accountBalance:number;
  ngOnInit() {
    var balance = this.bankService.showBalance();
    if(balance != -1){
      this.accountBalance = balance;
    }
    else{
      this.accountBalance = 0;
    }
  }

}
