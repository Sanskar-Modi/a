import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-operations',
  templateUrl: './user-operations.component.html',
  styleUrls: ['./user-operations.component.css']
})
export class UserOperationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
