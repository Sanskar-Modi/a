import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router'
import { BankService } from '../../Service/bank.service'

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  depositForm: FormGroup
  submitted: boolean = false;

  get f() { return this.depositForm.controls; }

  constructor(private formBuilder: FormBuilder, private router: Router, private bankService: BankService) {
    this.formBuilder = formBuilder;;
  }

  ngOnInit() {

    this.depositForm = this.formBuilder.group({
      amount: ['', [
        Validators.required,
        Validators.maxLength(10),
        Validators.pattern('[0-9]+')  // validates input is digit
      ]]
    });
  }


  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.depositForm.invalid) {
      return;
    }

    var amount = this.depositForm.get("amount").value;
    var isDeposited = this.bankService.depositAmount(amount);
    if (isDeposited != -1) {
      alert('Deposit successful. Current Balance : ' +this.bankService.showBalance());
      this.router.navigate(['/useractions']);
    }
    else {
      alert('Deposit Failed , Try again');
      this.router.navigate(['/useractions/deposit']);
    }


  }


}
