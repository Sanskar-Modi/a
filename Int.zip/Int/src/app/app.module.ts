import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule }    from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DepositComponent } from './Operations/deposit/deposit.component';
import { WithdrawComponent } from './Operations/withdraw/withdraw.component';
import { CreateAccountComponent } from './Operations/create-account/create-account.component';
import { ShowBalanceComponent } from './Operations/show-balance/show-balance.component';
import { FundTransferComponent } from './Operations/fund-transfer/fund-transfer.component';
import { PrintTransactionsComponent } from './Operations/print-transactions/print-transactions.component';
import { LoginComponent } from './Operations/login/login.component';
import { UserOperationsComponent } from './Operations/user-operations/user-operations.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    DepositComponent,
    WithdrawComponent,
    CreateAccountComponent,
    ShowBalanceComponent,
    FundTransferComponent,
    PrintTransactionsComponent,
    LoginComponent,
    UserOperationsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
