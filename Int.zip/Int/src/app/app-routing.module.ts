import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAccountComponent } from './Operations/create-account/create-account.component';
import { LoginComponent } from './Operations/login/login.component';
import { DepositComponent } from './Operations/deposit/deposit.component';
import { UserOperationsComponent } from './Operations/user-operations/user-operations.component';
import { WithdrawComponent } from './Operations/withdraw/withdraw.component';
import { ShowBalanceComponent } from './Operations/show-balance/show-balance.component';
import { FundTransferComponent } from './Operations/fund-transfer/fund-transfer.component';
import { PrintTransactionsComponent } from './Operations/print-transactions/print-transactions.component';


const routes: Routes = [
  { path: '', redirectTo: 'create', pathMatch: 'full' },
  {
    path:"create",
    component:CreateAccountComponent
  },
  {
    path:"login",
    component: LoginComponent
  },
  
  {
    path:"useractions",
    component:UserOperationsComponent
  },
  {
    path:"useractions/deposit",
    component:DepositComponent
  },
  {
    path:"useractions/withdraw",
    component:WithdrawComponent
  },
  {
    path:"useractions/showbalance",
    component:ShowBalanceComponent
  },
  {
    path:"useractions/fundtransfer",
    component:FundTransferComponent
  },
  {
    path:"useractions/print",
    component:PrintTransactionsComponent
  },
  { path: "useractions/logout", redirectTo: 'create', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
