import { Injectable } from '@angular/core';
import {Bank} from '../Models/Bank'
import { Transactions } from '../Models/Transactions';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BankService {
response:any;
  registerUsers:Bank[] = []
  transactions:Transactions[] = []

  currentUserAccId:number;
  currentUserAccPass:string;
  http:HttpClient
  loginAccount:number;

  constructor(http:HttpClient) {
      this.http = http
    
   }

  accountIdGenerator():number{
    return Math.floor(Math.random() * 10000);
  }

  createAccount(username:string,password:string,mobilenumber:number,address:string,balance:number):Observable<any>{
       
        let url = 'http://localhost:1111/Bank/createAccount';
        var jSONObject = {
          "name":username,
          "password":password,
          "mobNo":mobilenumber,
          "address":address,
          "bal":balance
        }
       return this.http.post(url,jSONObject)

   
    
  }

  // depositAmount(amount:any):Observable<any>{
  //   let url = 'http://localhost:1111/Bank/deposit/';
  
 
  // }
withdrawAmount(amount:any):number{
    for(let i = 0; i < this.registerUsers.length ; i++){
        
      if(this.currentUserAccId == this.registerUsers[i].accountNumber && this.currentUserAccPass == this.registerUsers[i].accountPassword ){
        
        if(this.registerUsers[i].balance < amount){
          return -1
        }

        this.registerUsers[i].balance = this.registerUsers[i].balance - parseInt(amount,10)
        var today = new Date();
        var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
        var tObj = new Transactions(this.currentUserAccId,"Withdraw",date,amount,null)
        this.transactions.push(tObj)
        return this.registerUsers[i].balance;
      }
    }
    return -1;
  }

  showBalance(){
    for(let i = 0; i < this.registerUsers.length ; i++){
        
      if(this.currentUserAccId == this.registerUsers[i].accountNumber && this.currentUserAccPass == this.registerUsers[i].accountPassword ){     
        return this.registerUsers[i].balance;
      }
    }
    return -1;
  }


  fundTransfer(accountid:any,amount:any):boolean{
    var to:boolean = false;
    var from:boolean = false;
    for(let i = 0; i < this.registerUsers.length ; i++){
        
      if(this.currentUserAccId == this.registerUsers[i].accountNumber && this.currentUserAccPass == this.registerUsers[i].accountPassword ){
        
        if(this.registerUsers[i].balance < amount){
          return false
        }

        this.registerUsers[i].balance = this.registerUsers[i].balance - parseInt(amount,10)
        from = true
        var today = new Date();
        var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
        var tObj = new Transactions(this.currentUserAccId,"Fund Transfer To",date,amount,accountid)
        this.transactions.push(tObj)
        break;
      }
    }

    for(let i = 0; i < this.registerUsers.length ; i++){
        
      if(accountid == this.registerUsers[i].accountNumber){
        
        this.registerUsers[i].balance = this.registerUsers[i].balance + parseInt(amount,10)
        to = true;
        var today = new Date();
        var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
        var tObj = new Transactions(accountid,"Fund Transfer From",date,amount,this.currentUserAccId)
        this.transactions.push(tObj)
        break;
      }
    }
    if(to && from){
      return true
    }
    else{
      return false;
    }
  }


  printTransactions():Transactions[]{
    let trans:Transactions[] = [];
    for(let i = 0; i < this.transactions.length ; i++){
      
      if(this.currentUserAccId == this.transactions[i].accountNumber ){
        trans.push(this.transactions[i]);
      }
    }
    return trans;
  }

loginUser(accountid:number,password:string):boolean{
    if(this.registerUsers.length != 0){
      for(let i = 0; i < this.registerUsers.length ; i++){
        
        if(accountid == this.registerUsers[i].accountNumber && password == this.registerUsers[i].accountPassword ){
          console.log("success")
          this.currentUserAccId = accountid;
          this.currentUserAccPass = password;
          return true;
        }
      }
      return false;
    }
    else{
      console.log("this error")
      return false;
    }
    
  }

}
