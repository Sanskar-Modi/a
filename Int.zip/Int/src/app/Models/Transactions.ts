export class Transactions
{
    accountNumber:number;
    transactionType:String;
    transactionDate:String;
    transactionAmount:number;
    toAccountId:number;
    constructor(accountId:number,transactionType:String,transactionDate:String,transactionAmount:number,
        toAccountId:number){
            this.accountNumber = accountId;
            this.transactionType = transactionType;
            this.transactionAmount = transactionAmount;
            this.transactionDate = transactionDate;
            this.toAccountId = toAccountId;
        }
}