
export class Bank{

    accountNumber:number;
    accountUsername:String;
    accountPassword:String;
    phoneNumber:number;
    balance:number = 0;

    constructor(accountNumber:number,accountPassword:string,accountUsername:String,phoneNumber:number){
       
        this.accountNumber = accountNumber;
        this.accountPassword = accountPassword;
        this.accountUsername = accountUsername;
        this.phoneNumber = phoneNumber
        this.balance = 0;
    }

}